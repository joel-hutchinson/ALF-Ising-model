export file="Den_R0"
if [ ! -e $file  ]; then
    echo "Den_R0 does not exist"
fi
