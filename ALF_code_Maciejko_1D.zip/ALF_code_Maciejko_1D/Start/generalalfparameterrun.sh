
declare -a var=('ham_h')


Uval=($(seq 0.01 4 0.4))

#maxproc=8


#sed_inith="21 s/*/Ham_h  = ${hval[0]}.d0/";
#sed "$sed_inith" -i parameters;
sed 's/^Ham_h .*$/Ham_h = 0.1d0/' -i parameters;

#count1=1

#if [ "${#hval[@]}" -eq 1 ]
#then
#    max1="${#hval[@]}"
#else
#    max1=`expr "${#hval[@]}" - 1`
#fi

#while [ "$count1" -le "$max1" ]; do
#    if [ "${#hval[@]}" -eq 1 ]
#    then
#        mkdir "h${hval[0]}"
#        cp parameters "h${hval[0]}";
#        cp analysis.sh "h${hval[0]}";
#        cp seeds "h${hval[0]}";

#        cd "h${hval[0]}";
#        count1=`expr "$count1" + 1`
        #touch "index${hval[0]}".txt;
        #touch "energy${hval[0]}".txt;
        #touch "magnet${hval[0]}".txt;
        #touch "hval${hval[0]}".txt;
#    else
#        countm1=`expr "$count1" - 1`;
#        mkdir "h${hval[$count1]}";
#        sed_paramh="21 s/Ham_h  = ${hval[$countm1]}/Ham_h  = ${hval[$count1]}/";
#        sed -i "$sed_paramh" parameters;
#        cp parameters "h${hval[$count1]}";
#        cp analysis.sh "h${hval[$count1]}";
#        cp seeds "h${hval[$count1]}";

#        cd "h${hval[$count1]}";
        #touch "index${hval[$count1]}".txt;
        #touch "energy${hval[$count1]}".txt;
        #touch "magnet${hval[$count1]}".txt;
        #touch "hval${hval[$count1]}".txt;
#    fi
#    $DIR/Prog/Examples.out &
#    cd ../
#    count1=`expr "$count1" + 1`
#done

#echo "montecarlo step complete"
