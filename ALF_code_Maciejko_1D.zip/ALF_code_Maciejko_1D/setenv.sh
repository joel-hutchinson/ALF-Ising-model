export DIR=`pwd`
